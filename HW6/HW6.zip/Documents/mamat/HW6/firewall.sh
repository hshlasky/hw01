#!/bin/bash
  
#get all the rules without the comments

read packets

while read line; do
        one_rule=$(echo $line | grep -o '^[^#]*')

        if ([ ! -z "$one_rule" ])
        then
                rule_one=$(echo $one_rule|awk -F, '{print $1}')
                rule_two=$(echo $one_rule|awk -F, '{print $2}')
                rule_three=$(echo $one_rule|awk -F, '{print $3}')
                rule_four=$(echo $one_rule|awk -F, '{print $4}')
                
		./firewall.exe $rule_one | ./firewall.exe $rule_two | ./firewall.exe $rule_three | ./firewall.exe $rule_four >> out.txt 
        fi
done <$1
